#include <stdio.h>
#include <stdlib.h>

struct test
{
    int a;
    char b;
};

int main()
{
    struct test zm = {-4,'W'};
    int*p;
    p=&zm; // p=0x060fef0  , *p=-4
    char w = zm.b; // w=W  , &w=0x60fefb
    p++; // p=0x60fef4  , *p=87
    w--; // w=V  , &w=86
    zm.b=99;  // w=V  , &w=0x60fefb
    return 0;
}
