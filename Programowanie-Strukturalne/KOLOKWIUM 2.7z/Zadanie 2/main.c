#include <stdio.h>
#include <stdlib.h>
int dl(char *napis)
{
    int x=0;
    while(napis[x]!=NULL)
    {
    x++;
    }
    return x;
}
char foo(char *napis)
{
    int x=dl(napis);
    if (x==0) return '\0';
    for(int i=x-1;i>=0;i=i-1)
    {
        if(napis[i]>96 && napis[i]<123)
        {
        return napis[i];
        }
    }
    return '\0';
}
int main()
{
    char str[50]="ABCDSESDFSF";
    printf("%s\n",str);
    printf("%c",foo(str));
    return 0;
}
