#include <stdio.h>
#include <stdlib.h>
int *foo(int m,int tab[][m],int n)
{
    int wsk;
    wsk=&tab[n-1][m-1];
    return wsk;
}
int main()
{
    int tab[2][2]={{1,2},{3,4}};
    int tab2[3][3]={{4,3},{6,4}};
    printf("%p\n",foo(tab,2,2));
    printf("%p\n",foo(tab2,3,3));
    return 0;
}
