#include <stdio.h>
#include <stdlib.h>
struct samolot
{
    char model[50];
    int liczba_silnikow;
};
struct samolot najm(struct samolot tab[],int n)
{
    int temp=0;
    int temp2=tab[0].liczba_silnikow;
    for (int i=1;i<n;i++)
    {
        if(tab[i].liczba_silnikow<temp2)
        {
        temp2=tab[i].liczba_silnikow;
        temp=i;
        }
    }
    return tab[temp];
}
int main()
{
    struct samolot lista[]={{.model="spitfire",.liczba_silnikow=3},{.model="fallcon",.liczba_silnikow=4},{.model="messerschmitt",.liczba_silnikow=2}};
    struct samolot n;
    n=najm(lista,3);
    printf("%s - %i",n.model,n.liczba_silnikow);
    return 0;
}
