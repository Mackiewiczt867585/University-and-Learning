#include <stdio.h>
#include <stdlib.h>
struct element
{
    int x;
    struct element * next;
};
int foo(struct element * lista1,struct element * lista2)
{
    int min1=lista1->x,min2=lista2->x,max1=lista1->x,max2=lista2->x;
    lista1=lista1->next;
    lista2=lista2->next;
    while(lista1->next!=NULL)
    {
        if(lista1->x<min1)
        {
            min1=lista1->x;
        }
        if(lista1->x>max1)
        {
            max1=lista2->x;
        }
        lista1=lista1->next;
    }
    while(lista2->next!=NULL)
    {
        if(lista2->x<min2)
        {
            min2=lista2->x;
        }
        if(lista2->x>max2)
        {
            max2=lista2->x;
        }
        lista2=lista2->next;
    }
    if(max1-min1==max2-min2) return 1;
    return 0;
}
int main()
{
    struct element * lista1=malloc(sizeof(struct element));
    lista1->x=1;
    lista1->next=malloc(sizeof(struct element));
    lista1->next->x=2;
    lista1->next->next=NULL;
    struct element * lista2=malloc(sizeof(struct element));
    lista2->x=3;
    lista2->next=malloc(sizeof(struct element));
    lista2->next->x=4;
    lista2->next->next=NULL;
    printf("%i",foo(lista1,lista2));
    return 0;
}
