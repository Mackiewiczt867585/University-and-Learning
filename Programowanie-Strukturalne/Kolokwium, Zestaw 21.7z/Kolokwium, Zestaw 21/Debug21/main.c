#include <stdio.h>
#include <stdlib.h>

void foo(int* tab, int n)
{
    for(int i=0;i<n;i++)
    {
        *(tab+i)*=3;
    }
}

int main()
{
    int tab[] = {1,-3,2,2,9,8};
    int *wsk=tab-2;
    foo(wsk,5);
    int b = *(wsk+=4); //b=6
    int c = b+2; // b=6  , c=8
    int d = b^c; // b=6  , c=8  , d=14
    int e = (wsk+=-1)[2]; // b=6  , c=8  , d=14  , e=2
    e = (d *= 8) + (c /= 3); // b=6  , c=2  , d=112  , e=114
    c = d - (b+=8); // b=14  , c=98  , d=112  , e=114
    b = *wsk + e; // b=105  , c=98  , d=112  , e=114
    return 0;
}
