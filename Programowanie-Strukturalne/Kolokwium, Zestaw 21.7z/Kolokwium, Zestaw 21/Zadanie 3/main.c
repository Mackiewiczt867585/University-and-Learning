#include <stdio.h>
#include <stdlib.h>
int foo (unsigned int n)
{
    int il=1;
    for(int i=1;i<n;i++)
    {
        if(i%2==0) il*=i;
    }
    return il;
}
int main()
{
    printf("%i\n",foo(3));
    printf("%i\n",foo(12));
    return 0;
}
