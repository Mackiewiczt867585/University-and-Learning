#include <stdio.h>
#include <stdlib.h>
int foo (int (*fun1)(int a),int (*fun2)(int a),int n)
{
    for (int i=0;i<=n;i++)
    {
    if (fun1(i)!=fun2(i) && i%2==0) return -1;
    }
    return 2;
}
int f1 (int n)
{
    return n*n;
}
int f2 (int n)
{
    return 2*n;
}
int main()
{
    printf("%i\n",foo(&f1,&f2,4));
    return 0;
}
