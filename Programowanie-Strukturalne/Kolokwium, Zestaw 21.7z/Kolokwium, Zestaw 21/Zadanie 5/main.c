#include <stdio.h>
#include <stdlib.h>
int foo (unsigned int n)
{
    if (n==0 || n==1) return 2;
    if (n%2==0) return foo(n/2)+3;
    if (n%2==1) return foo(n-1)-1;
}
int main()
{
    printf("%i\n",foo(2));
    printf("%i\n",foo(4));
    return 0;
}
