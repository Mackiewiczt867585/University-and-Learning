#include <stdio.h>
#include <stdlib.h>
void wypisz (int n,int tab[])
{
    for(int i=0;i<n;i++)
    {
    printf("%i,",tab[i]);
    }
}
int fib(int n)
{
    if (n==0) return 0;
    if (n==1) return 1;
    return fib(n-1)+fib(n-2);
}
void wpisz (int n,int * tab[])
{
    for(int i=0;i<n;i++)
    {
    tab[i]=fib(i);
    }
}
int main()
{
    int tab[30]={};
    wpisz(30,tab);
    wypisz(30,tab);
    return 0;
}
